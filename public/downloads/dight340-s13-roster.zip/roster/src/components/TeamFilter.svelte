<script>
  import { matchesQuery, teamSize } from '../lib/team.js';

  let { trainers, sprites } = $props();
  let query = $state('');
  let shown = $state([]);

  $effect(() => {
    shown = trainers.filter((trainer) => matchesQuery(trainer, query));
  });
</script>

<label for="query">Find a trainer</label>
<input id="query" bind:value={query} />

<ul>
  {#each shown as trainer}
    <li>
      <img src={sprites[trainer.id]} alt={trainer.team[0]} width="48" height="48" />
      <strong>{trainer.name}</strong> ({teamSize(trainer)}): {trainer.team.join(', ')}
    </li>
  {/each}
</ul>
