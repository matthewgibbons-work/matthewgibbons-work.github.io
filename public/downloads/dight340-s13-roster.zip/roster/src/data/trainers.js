// Every trainer in the club this season. Pokémon names are PokéAPI names, lowercase.
export const trainers = [
  { id: 'ana', name: 'Ana', team: ['bulbasaur', 'pidgey', 'jigglypuff'] },
  { id: 'dev', name: 'Dev', team: ['charmander', 'geodude', 'zubat', 'oddish'] },
  { id: 'kai', name: 'Kai', team: ['squirtle', 'pikachu'] },
  { id: 'mei', name: 'Mei', team: ['eevee', 'snorlax', 'abra', 'machop', 'psyduck'] },
  { id: 'sam', name: 'Sam', team: ['growlithe', 'poliwag', 'magnemite'] },
];
