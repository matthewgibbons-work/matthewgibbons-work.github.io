# League Roster

The Saturday Pokémon club's roster: who's in the club this season, and who's on each trainer's team. Club members check it on their phones before meetups, and the organiser updates it most weeks.

Built quickly by a club member, with Claude, then handed on to you.

## Run it

```
npm install
npm run dev       # http://localhost:4321
npm run build     # the site, in dist/
npm run preview   # the built site
npx vitest run    # the tests
```

## Where things live

- `src/data/trainers.js`: every trainer and their team.
- `src/pages/`: the pages (home, trainers).
- `src/layouts/Base.astro`: the layout and nav every page shares.
- `src/components/TeamFilter.svelte`: the search box on the trainers page.
- `src/lib/team.js`: small helpers, tested in `src/lib/team.test.js`.

## The weekly job

Most weeks the organiser asks for a new trainer: their name, an id (lowercase, no spaces), and up to six Pokémon (PokéAPI names, lowercase). The trainer goes at the end of `src/data/trainers.js`, and the trainers page picks them up.
